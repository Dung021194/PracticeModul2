import Manager.ProductManager;
import Model.Product;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        ProductManager productManager = new ProductManager();
        Scanner scanner = new Scanner(System.in);
        String path = "products.csv";
        int choice;
        try {
            do {
                System.out.println("---CHƯƠNG TRÌNH QUẢN LÝ SẢN PHẨM---");
                System.out.println("chọn chức năng theo số (để tiếp tục)");
                System.out.println("1. Xem danh sách");
                System.out.println("2. Thêm mới");
                System.out.println("3. Cập nhật");
                System.out.println("4. Xóa");
                System.out.println("5. Sắp xếp");
                System.out.println("6. Tìm sản phẩm theo giá đắt nhất");
                System.out.println("7. Đọc từ file");
                System.out.println("8. Ghi  vào file");
                System.out.println("9. Thoát");
                System.out.println("Chọn chức năng");
                choice =Integer.parseInt(scanner.nextLine());
                switch (choice){
                    case 1:
                        productManager.displayAllProduct();
                        break;
                    case 2:
                        Product product = productManager.createProduct(scanner);
                        if (product!=null){
                        productManager.listProduct.add(product);}
                        break;
                    case 3:
                        productManager.updateProduct(scanner);
                        break;
                    case 4:
                        productManager.deleteProduct(scanner);
                        break;
                    case 5:
                        productManager.sortByPrice();
                        break;
                    case 6:
                        productManager.findMaxPrice();
                        break;
                    case 7:
                        productManager.listProduct = productManager.read(path);
                        break;

                    case 8:
                        productManager.writeCsv(productManager.listProduct,path);
                        break;

                }


            }while (choice !=9);

        } catch (NumberFormatException e) {
            e.getStackTrace();
        }
    }
}