package Manager;

import Model.Product;

import javax.sound.midi.MidiDevice;
import java.io.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ProductManager {
     public ArrayList<Product> listProduct;

    public ProductManager() {
        listProduct = new ArrayList<>();
    }
    public static boolean checkRegex(String checkInput, String compileRegex) {
        Pattern pattern = Pattern.compile(compileRegex);
        Matcher matcher = pattern.matcher(checkInput);
        return matcher.matches();
    }
    public void display(Product product){
        System.out.printf("%10s%15s%15s%15s%15s",product.getId(),product.getName(),
                product.getPrice(),product.getQuantity(),product.getDetail());
    }
    public void displayAllProduct(){
        System.out.printf("%10s%15s%15s%15s%15s","ID","NAME","PRICE","QUANTITY","DETAIL");
        System.out.println();
        for (Product p:listProduct){
            display(p);
            System.out.println();
        }
    }
    public Product createProduct(Scanner scanner){
        int id;
        double price = 0;
        int quantity=0;
        if (listProduct.isEmpty()){
            id = 1;
        }else {
            id= listProduct.get(listProduct.size()-1).getId()+1;
        }
        System.out.println("Enter name of product:");
        String name = scanner.nextLine();
        System.out.println("Enter price of product:");
        String priceInput = scanner.nextLine();
        if (checkRegex(priceInput,"^[0-9]+\\.?[0-9]*$")){
            price = Double.parseDouble(priceInput);
        }else {
            System.out.println("Wrong format, enter again");
        }
        System.out.println("Enter quantity of product:");
        String quantityInput = scanner.nextLine();
        if (checkRegex(quantityInput,"^[0-9]+$")){
            quantity = Integer.parseInt(quantityInput);
        }else {
            System.out.println("Wrong format, enter again");
        }
        System.out.println("Enter detail of product");
        String detail = scanner.nextLine();

        return new Product(id,name,price,quantity,detail);

    }
    public Product findProductByID(Scanner scanner){
        Product findProduct = null;
        boolean flag = true;
        do {
        System.out.println("Enter ID of product:");
        String idFindInput = scanner.nextLine();
        if (!idFindInput.equals("")) {
        if (checkRegex(idFindInput,"[0-9]+$")){
            int idFind = Integer.parseInt(idFindInput);
            for (Product p : listProduct){
                if (p.getId()==idFind){
                    findProduct = p;
                    flag = false;
                    break;
                }
            }
            if (flag){
                System.out.println("ID out of list");
            }

        }else {
            System.out.println("Wrong format, enter again");
        }
        }
        }while (flag);
        return findProduct;
    }
    public void updateProduct(Scanner scanner){
        boolean flag = true;
        Product editProduct = findProductByID(scanner);
        System.out.println("Enter new name of product");
        String name =scanner.nextLine();
        if (!name.equals("")){
            editProduct.setName(name);
        }
        do {
        System.out.println("Enter new price of product:");
        String price = scanner.nextLine();
        if (!price.equals("")){
            if (checkRegex(price,"^[0-9]+\\.?[0-9]*$")){
                editProduct.setPrice(Double.parseDouble(price));
                flag = false;
            }else {
                System.out.println("Wrong format, enter again");
            }
        }else {
            flag =false;
        }
        }while (flag);

        do {
            System.out.println("Enter new quantity of product:");
            String quantity = scanner.nextLine();
            if (!quantity.equals("")){
                if (checkRegex(quantity,"^[0-9]+$")){
                    editProduct.setQuantity(Integer.parseInt(quantity));
                    flag = true;
                }else {
                    System.out.println("Wrong format, enter again");
                }
            }else {
                flag =true;
            }
        }while (!flag);

            System.out.println("Enter new detail of product:");
            String detail = scanner.nextLine();
            if (!detail.equals("")){
                editProduct.setDetail(detail);
            }

        System.out.println("Update product success");

        }
        public void deleteProduct(Scanner scanner){
            Product delProduct = findProductByID(scanner);
            if (delProduct!=null){
                System.out.println("Do you want to delete this product(Press y to ok, any key to cancel)");
                String choiceDel = scanner.nextLine();
                if (choiceDel.equalsIgnoreCase("y")){
                listProduct.remove(delProduct);
                System.out.println(" Delete success");
                }
            }
            else {
                System.out.println(" Delete fail");
            }

        }

    public void sortByPrice() {
        listProduct.sort(new Comparator<Product>() {
            @Override
            public int compare(Product o1, Product o2) {
                return o1.getPrice() > o2.getPrice() ? 1 : -1;
            }
        });
        displayAllProduct();
    }
        public void findMaxPrice(){
        if (!listProduct.isEmpty()){
        double max = listProduct.get(0).getPrice();
        for (Product product: listProduct){
            if (product.getPrice()>max){
                max = product.getPrice();
            }
        }
        for (Product product:listProduct){
            if (product.getPrice()==max){
                display(product);
                System.out.println();
            }
        }
        }else {
            System.out.println("No product");
        }
    }


    public void writeCsv(ArrayList<Product> list, String path) {
        try {
            FileWriter fileWriter = new FileWriter(path);
            BufferedWriter bw = new BufferedWriter(fileWriter);
            for (Product product : list) {
                bw.write(product.toString());
                bw.newLine();

            }
            bw.newLine();
            bw.close();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }


    }
    public ArrayList<Product> read(String path){
        ArrayList<Product> list = new ArrayList<>();
        try {
            FileReader fileReader = new FileReader(path);
            BufferedReader br = new BufferedReader(fileReader);
            String line = "";
            while ((line=br.readLine())!=null){
                String [] txt = line.split(";");
                int id = Integer.parseInt(txt[0]);
                String name = txt[1];
                double price = Double.parseDouble(txt[2]);
                int quantity = Integer.parseInt(txt[3]);
                String detail = txt[4];
                list.add(new Product(id,name,price,quantity,detail));
            }
            br.close();
        } catch (Exception e) {
            e.getStackTrace();
        }
        return list;
    }


}
